#!/bin/bash

cd Root
for i in {1..1000}
do
	echo $i
	#mkdir a
	cd a
done

#ls -lah > file
cat file
ls -lah file
